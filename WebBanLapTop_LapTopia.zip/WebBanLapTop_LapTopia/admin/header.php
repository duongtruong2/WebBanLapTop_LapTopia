<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/home_admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
</head>

<body>
    <div class="container">
        <div class="headeradmin">
            <h2>LAPTOPIA</h2>
        </div>
        <div class="menu_admin">
            <ul>
                <li><a href="index.php">Trang chủ</a></li>
                <li><a href="index.php?act=listdm">Danh mục</a></li>
                <li><a href="index.php?act=listsp">Sản phẩm</a></li>
                <li><a href="index.php?act=listtk">Khách hàng</a></li>
                <li><a href="index.php?act=listdh">Đơn hàng</a></li>
                <li><a href="index.php?act=listbl">Bình luận</a></li>

               

            </ul>
            <span><a href="../view/index.php" class="home"><i class="fa-solid fa-house"></i> Quay về WEBSITE</a></span>
        </div>
        <!-- END HEADER -->