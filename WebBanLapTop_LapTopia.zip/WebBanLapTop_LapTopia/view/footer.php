<div class="footer">
    <div class="content-logo">
        <div class="logo">
            <img src="../image/logo5.png" alt="">
        </div>
        <p>Hotline: 1900 96 96 01</p>
        <p>Email: contact@laptopia.vn</p>
        <span>Công ty TNHH Laptopia Việt Nam</span>
    </div>
    <div class="box">
        <p>CHÍNH SÁCH</p>
        <ul>
            <li>Chính sách mua hàng từ xa</li>
            <li>Chính sách đặt cọc sản phẩm</li>
            <li>Chính sách giao nhận - đổi trả</li>
            <li>Chính sách bảo hành</li>
            <li>Chính sách bảo mật thông tin</li>
            <li>Thỏa thuận sử dụng và quy định giao dịch chung</li>
            <li>Thỏa thuận sử dụng và quy định giao dịch chung</li>
        </ul>
    </div>
    <div class="box">
        <p>HỖ TRỢ KHÁCH HÀNG</p>
        <ul>
            <li>Hỗ trợ sản phẩm</li>
            <li>Hỗ trợ kỹ thuật</li>
            <li>Tải driver</li>
            <li>Hỏi đáp</li>
        </ul>
    </div>
    <div class="box">
        <p>THANH TOÁN</p>
        <ul>
            <li>Thanh toán trực tuyến (Internet Banking)</li>
            <li>Thanh toán khi nhận hàng (COD)</li>
            <li>Hướng dẫn thanh toán VNPAY</li>
        </ul>
    </div>
</div>
</div>
<script src="../main.js"></script>
</body>

</html>