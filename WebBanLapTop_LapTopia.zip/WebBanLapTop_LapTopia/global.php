<?php 
$image_path="../upload/";
?>